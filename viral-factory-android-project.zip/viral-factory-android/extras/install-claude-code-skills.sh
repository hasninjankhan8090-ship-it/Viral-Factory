#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/ai-video-generator-claude/skills"
DEST="${1:-$HOME/.claude/skills}"
mkdir -p "$DEST"
count=0
for skill_dir in "$SRC"/*; do
  [ -f "$skill_dir/SKILL.md" ] || continue
  name="$(basename "$skill_dir")"
  target="$DEST/$name"
  if [ -e "$target" ]; then
    echo "Skipping existing skill: $target (remove it first to replace)"
    continue
  fi
  cp -R "$skill_dir" "$target"
  echo "Installed: $name"
  count=$((count+1))
done
echo "Installed $count skill(s) into $DEST"
echo "Restart Claude Code to load the skills."
