# VIRAL FACTORY for Android

An Android WebView application that bundles the VIRAL FACTORY creator interface and uses a native Android bridge for provider requests. The app UI and saved drafts are available offline; AI collaboration, live trend research, and cloud voice generation require internet and valid provider API keys.

## Build an APK with GitHub Actions (no Android SDK needed on your phone)

1. Create a GitHub repository and upload the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build VIRAL FACTORY APK** and tap **Run workflow** (or wait for the first push build).
4. Open the completed workflow run and download the `viral-factory-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser/files app.

## Build locally

Open this folder in Android Studio (Giraffe or newer), let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Requires JDK 17 and Android SDK platform 35.

## Features

- Story idea lanes and built-in story seeds
- Sequential ChatGPT → Claude → ChatGPT collaboration
- Optional OpenAI-powered trend research
- OpenAI and ElevenLabs voice generation
- Free Android/browser speech playback fallback
- Local workspace shell and offline-accessible UI

## Important limitations

- The included app is a production-planning and narration studio. It does not directly generate cinematic footage or render the included Remotion project on Android. Actual text-to-video footage requires a separate provider and its API/credits; the supplied Remotion kit is intended for a computer-based render workflow.
- Provider API keys are entered into the app session and are sent to the respective provider. API usage is billed separately from ChatGPT/Claude subscriptions. Do not share your keys.
- The APK produced by this workflow is a debug APK, not a Play Store release-signed APK.
- Review model availability and API pricing with OpenAI and Anthropic before use; provider model names can change.
