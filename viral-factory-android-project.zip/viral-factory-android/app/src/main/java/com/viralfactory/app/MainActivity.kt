package com.viralfactory.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import android.util.Base64

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pool = Executors.newSingleThreadExecutor()
    private val systemPrompt = "You are part of VIRAL FACTORY, a premium short-form content studio. Create engaging vertical-video stories with a powerful 1-3 second hook, escalating curiosity, vivid visual beats, emotional stakes, satisfying payoff and memorable ending. Avoid fake facts. Clearly label fiction as fiction. For real stories, never invent details and flag claims needing verification. Give scene-by-scene visuals, camera direction, sound design and narration. Do not imitate a living creator's exact style; translate references into broad traits."

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "VFNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun request(path: String, body: String, callbackId: String) {
            pool.execute {
                try {
                    val input = JSONObject(body)
                    val result = when (path) {
                        "/api/health" -> JSONObject().put("ok", true).put("studio", "VIRAL FACTORY Android")
                        "/api/trends" -> trends(input)
                        "/api/collaborate" -> collaborate(input)
                        "/api/voice" -> voice(input)
                        "/api/project" -> JSONObject().put("ok", true).put("slug", slug(input.optString("title"))).put("path", "Saved on this device").put("commands", JSONArray())
                        else -> JSONObject().put("error", "Unknown request")
                    }
                    deliver(callbackId, 200, if (path == "/api/voice") "audio/mpeg" else "application/json", if (path == "/api/voice") result.optString("audio") else result.toString())
                } catch (e: ApiError) {
                    deliver(callbackId, e.status, "application/json", JSONObject().put("error", e.message ?: "Request failed").toString())
                } catch (e: Exception) {
                    deliver(callbackId, 500, "application/json", JSONObject().put("error", e.message ?: "Request failed").toString())
                }
            }
        }
    }

    private fun deliver(id: String, status: Int, type: String, body: String) {
        val encoded = JSONObject.quote(body)
        runOnUiThread { web.evaluateJavascript("window.__vfNativeResult('$id',$status,${JSONObject.quote(type)},$encoded)", null) }
    }

    private fun requestJson(url: String, headers: Map<String,String>, data: JSONObject): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection)
        c.requestMethod = "POST"; c.connectTimeout = 30000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k,v) -> c.setRequestProperty(k,v) }
        c.outputStream.use { it.write(data.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        c.disconnect()
        val obj = JSONObject(text)
        if (code !in 200..299) throw ApiError(code, obj.optJSONObject("error")?.optString("message") ?: text.take(600))
        return obj
    }

    private fun openAi(key: String, messages: JSONArray, model: String = "gpt-5.4-mini"): String {
        val payload = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.85)
        val j = requestJson("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), payload)
        return j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: ""
    }

    private fun claude(key: String, system: String, user: String): String {
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", user))
        val payload = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 3500).put("system", system).put("messages", messages)
        val j = requestJson("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), payload)
        val content = j.optJSONArray("content") ?: JSONArray()
        return (0 until content.length()).mapNotNull { content.optJSONObject(it)?.takeIf { x -> x.optString("type") == "text" }?.optString("text") }.joinToString("\n")
    }

    private fun trends(b: JSONObject): JSONObject {
        val key = b.optString("openaiKey")
        if (key.isBlank()) throw ApiError(400, "OpenAI API key required for live trend research.")
        val prompt = "Research current short-form video trends and shareable story topics. Focus on AI-generated story videos, mysterious true stories, strange history, scams, horror fiction and fast visual explainers. Return 8 original ideas with title, REAL/FICTION/FORMAT TREND label, retention rationale, hook and source links. Do not invent view counts. User lane: ${b.optString("lane", "all lanes")}."
        val payload = JSONObject().put("model", "gpt-5-search-api").put("web_search_options", JSONObject().put("search_context_size", "medium")).put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt)).put(JSONObject().put("role", "user").put("content", prompt)))
        val j = requestJson("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), payload)
        val text = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: "No trend ideas returned."
        return JSONObject().put("text", text)
    }

    private fun collaborate(b: JSONObject): JSONObject {
        val story = b.optString("story").trim(); val ok = b.optString("openaiKey"); val ck = b.optString("claudeKey")
        if (story.isBlank()) throw ApiError(400, "Add a story idea first.")
        if (ok.isBlank() || ck.isBlank()) throw ApiError(400, "Add both OpenAI and Claude API keys in Settings.")
        val count = b.optString("rounds", "3").toIntOrNull()?.coerceIn(1,6) ?: 3
        val genre = b.optString("genre", "mystery"); val format = b.optString("format", "shorts"); val reference = b.optString("reference")
        val log = JSONArray()
        var draft = openAi(ok, JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt)).put(JSONObject().put("role", "user").put("content", "Develop this into an addictive $format video in $genre. Reference: ${reference.ifBlank { "none" }}. Story: $story. Return title, hook, outline, visual moments, twist/payoff, ending and factual questions.")))
        log.put(JSONObject().put("speaker", "ChatGPT").put("text", draft))
        for (i in 1..count) {
            val critique = claude(ck, "$systemPrompt You are the story editor. Be candid and specific. Critique weak hooks, predictable beats, logic, visuals and factual risks, then provide an improved version.", "Review and improve this draft:\n\n$draft")
            log.put(JSONObject().put("speaker", "Claude").put("text", critique))
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", "$systemPrompt You are the creative director. Integrate the strongest feedback and improve the story.")).put(JSONObject().put("role", "user").put("content", "Claude's review:\n$critique\n\nPrevious draft:\n$draft\n\nProduce the next improved draft. Flag factual claims requiring verification."))
            draft = openAi(ok, msgs)
            log.put(JSONObject().put("speaker", "ChatGPT").put("text", draft))
        }
        val final = claude(ck, "$systemPrompt You are the final story producer. Deliver a polished production-ready script and shot list. Label fiction and preserve factual accuracy.", "Prepare final production package: title, 3 hooks, exact voiceover narration, numbered scenes with visual prompt/camera/motion/on-screen text/SFX, music mood, ending, caption and hashtags. Draft:\n$draft")
        log.put(JSONObject().put("speaker", "Claude · Final Producer").put("text", final))
        return JSONObject().put("log", log).put("final", final).put("rounds", count)
    }

    private fun voice(b: JSONObject): JSONObject {
        val text = b.optString("text").trim(); if (text.isBlank()) throw ApiError(400, "Enter narration first.")
        val provider = b.optString("provider", "openai")
        val bytes: ByteArray = if (provider == "openai") {
            val key = b.optString("openaiKey"); if (key.isBlank()) throw ApiError(400, "OpenAI API key required.")
            val payload = JSONObject().put("model", "gpt-4o-mini-tts").put("voice", b.optString("voice", "cedar")).put("input", text).put("instructions", "Speak in a deep, intimate, mysterious documentary narrator voice. Clear diction, controlled pace, cinematic tension.").put("response_format", "mp3")
            requestBytes("https://api.openai.com/v1/audio/speech", mapOf("Authorization" to "Bearer $key"), payload)
        } else {
            val key = b.optString("elevenKey"); val id = b.optString("voiceId"); if (key.isBlank() || id.isBlank()) throw ApiError(400, "ElevenLabs API key and Voice ID required.")
            val payload = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2").put("voice_settings", JSONObject().put("stability", 0.42).put("similarity_boost", 0.78).put("style", 0.55).put("use_speaker_boost", true))
            requestBytes("https://api.elevenlabs.io/v1/text-to-speech/$id", mapOf("xi-api-key" to key, "Accept" to "audio/mpeg"), payload)
        }
        return JSONObject().put("audio", Base64.encodeToString(bytes, Base64.NO_WRAP))
    }

    private fun requestBytes(url: String, headers: Map<String,String>, data: JSONObject): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 30000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json"); headers.forEach { (k,v) -> c.setRequestProperty(k,v) }
        c.outputStream.use { it.write(data.toString().toByteArray()) }
        val code = c.responseCode; val stream = if (code in 200..299) c.inputStream else c.errorStream
        val out = ByteArrayOutputStream(); stream?.use { it.copyTo(out) }; c.disconnect()
        if (code !in 200..299) throw ApiError(code, String(out.toByteArray(), Charsets.UTF_8).take(600))
        return out.toByteArray()
    }

    private fun slug(s: String): String = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40).ifBlank { "my-viral-story" }
    override fun onDestroy() { pool.shutdown(); web.destroy(); super.onDestroy() }
    class ApiError(val status: Int, message: String) : Exception(message)
}
