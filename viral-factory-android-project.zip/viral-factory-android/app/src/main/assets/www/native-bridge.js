(() => {
  let nextId = 1;
  const pending = new Map();
  window.__vfNativeResult = (id, status, type, body) => {
    const item = pending.get(id);
    if (!item) return;
    pending.delete(id);
    if (type === 'audio/mpeg') {
      const raw = atob(body); const bytes = new Uint8Array(raw.length);
      for (let i=0;i<raw.length;i++) bytes[i] = raw.charCodeAt(i);
      item.resolve(new Response(new Blob([bytes], {type:'audio/mpeg'}), {status, headers:{'Content-Type':type}}));
    } else {
      item.resolve(new Response(body, {status, headers:{'Content-Type':type}}));
    }
  };
  const nativeFetch = (path, options={}) => new Promise((resolve, reject) => {
    const id = String(nextId++);
    pending.set(id, {resolve, reject});
    try { window.VFNative.request(path, options.body || '{}', id); }
    catch (e) { pending.delete(id); reject(e); }
  });
  const originalFetch = window.fetch.bind(window);
  window.fetch = (input, options={}) => {
    const url = typeof input === 'string' ? input : input.url;
    if (url.startsWith('/api/')) return nativeFetch(url, options);
    return originalFetch(input, options);
  };
})();
